import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { S as useMushaf, d as loadText, i as RECITERS, v as toArabicDigits } from "./audio-DSZp4en8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CQgHDd5P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useQuranText() {
	const [text, setText] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [attempt, setAttempt] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let live = true;
		setError(null);
		loadText().then((value) => {
			if (live) setText(value);
		}).catch((err) => {
			if (!live) return;
			setError(err instanceof Error ? err.message : "تعذّر تحميل نص المصحف");
		});
		return () => {
			live = false;
		};
	}, [attempt]);
	return {
		text,
		error,
		retry: () => setAttempt((n) => n + 1)
	};
}
function Sheet({ open, title, onClose, children }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = previous;
			window.removeEventListener("keydown", onKey);
		};
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "إغلاق",
			className: "scrim absolute inset-0",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "relative z-10 max-h-[86vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl border border-line bg-surface px-5 pt-4 pb-8 sm:rounded-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "إغلاق",
					onClick: onClose,
					className: "grid h-11 w-11 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})]
	});
}
function SettingsSheet({ open, onClose }) {
	const theme = useMushaf((state) => state.theme);
	const fontSize = useMushaf((state) => state.fontSize);
	const reciter = useMushaf((state) => state.reciter);
	const showPages = useMushaf((state) => state.showPages);
	const follow = useMushaf((state) => state.follow);
	const autoNextSurah = useMushaf((state) => state.autoNextSurah);
	const setTheme = useMushaf((state) => state.setTheme);
	const setFontSize = useMushaf((state) => state.setFontSize);
	const setReciter = useMushaf((state) => state.setReciter);
	const togglePages = useMushaf((state) => state.togglePages);
	const toggleFollow = useMushaf((state) => state.toggleFollow);
	const toggleAutoNext = useMushaf((state) => state.toggleAutoNext);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		title: "إعدادات القراءة",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm text-muted",
				children: "المظهر"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					on: theme === "night",
					onClick: () => setTheme("night"),
					children: "ليلي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					on: theme === "day",
					onClick: () => setTheme("day"),
					children: "نهاري"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "حجم الخط"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "basmala text-gold",
					style: { fontSize },
					children: "بِسۡمِ ٱللَّهِ"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Round, {
							onClick: () => setFontSize(fontSize - 2),
							label: "تصغير الخط",
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-center text-sm",
							children: toArabicDigits(fontSize)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Round, {
							onClick: () => setFontSize(fontSize + 2),
							label: "تكبير الخط",
							children: "+"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm text-muted",
				children: "القارئ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 overflow-hidden rounded-xl border border-line",
				children: RECITERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": reciter === item.id,
					onClick: () => setReciter(item.id),
					className: "flex min-h-11 w-full items-center justify-between border-b border-line px-3 py-2 text-start last:border-b-0 " + (reciter === item.id ? "bg-surface-2 text-gold" : ""),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: item.name
					}), reciter === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						children: "مختار"
					}) : null]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				label: "فواصل الصفحات",
				hint: "إظهار رقم الصفحة والجزء أثناء القراءة",
				on: showPages,
				onToggle: togglePages
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				label: "متابعة التمرير",
				hint: "تحريك الصفحة مع الآية الجارية",
				on: follow,
				onToggle: toggleFollow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				label: "السورة التالية",
				hint: "متابعة التلاوة عند انتهاء السورة",
				on: autoNextSurah,
				onToggle: toggleAutoNext
			})
		]
	});
}
function Choice({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: "min-h-11 rounded-xl border px-3 text-sm font-medium " + (on ? "border-gold bg-gold-fill text-on-gold" : "border-line bg-bg text-fg"),
		children
	});
}
function Round({ onClick, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "grid h-11 w-11 place-items-center rounded-full border border-line text-lg",
		children
	});
}
function Toggle({ label, hint, on, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": on,
		onClick: onToggle,
		className: "flex w-full items-center justify-between gap-4 py-3 text-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-muted",
			children: hint
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 rounded-full px-3 py-1 text-xs font-medium " + (on ? "bg-gold-fill text-on-gold" : "bg-surface-2 text-muted"),
			children: on ? "يعمل" : "متوقف"
		})]
	});
}
//#endregion
export { Sheet as n, useQuranText as r, SettingsSheet as t };
