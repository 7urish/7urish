import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, i as Settings, m as Bookmark, r as Sun, u as Moon } from "../_libs/lucide-react.mjs";
import { S as useMushaf, _ as surahById, a as filterSurahs, g as searchAyahs, h as placeLabel, l as juz, n as PlayerDock, p as pageOf, s as globalIndex, t as BISMILLAH, u as juzOf, v as toArabicDigits, x as useHydrated } from "./audio-DSZp4en8.mjs";
import { r as useQuranText, t as SettingsSheet } from "./settings-CQgHDd5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B_-kXW0G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var QUICK = [
	{
		label: "آية الكرسي",
		s: 2,
		a: 255
	},
	{
		label: "يس",
		s: 36,
		a: 1
	},
	{
		label: "الرحمن",
		s: 55,
		a: 1
	},
	{
		label: "الملك",
		s: 67,
		a: 1
	},
	{
		label: "الكهف",
		s: 18,
		a: 1
	},
	{
		label: "الإخلاص",
		s: 112,
		a: 1
	}
];
function HomeView() {
	const navigate = useNavigate();
	const hydrated = useHydrated();
	const last = useMushaf((state) => state.last);
	const bookmarks = useMushaf((state) => state.bookmarks);
	const theme = useMushaf((state) => state.theme);
	const setTheme = useMushaf((state) => state.setTheme);
	const toggleBookmark = useMushaf((state) => state.toggleBookmark);
	const { text, error, retry } = useQuranText();
	const [query, setQuery] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("surah");
	const [settings, setSettings] = (0, import_react.useState)(false);
	const surahHits = (0, import_react.useMemo)(() => filterSurahs(query), [query]);
	const ayahHits = (0, import_react.useMemo)(() => text && query.trim().length >= 2 ? searchAyahs(text, query) : [], [text, query]);
	const searching = query.trim().length > 0;
	const lastMeta = last ? surahById(last.s) : void 0;
	const lastPage = last ? pageOf(globalIndex(last.s, last.a)) : null;
	const lastJuz = last ? juzOf(globalIndex(last.s, last.a)) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-2xl items-center justify-between px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-6 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base font-semibold leading-none",
							children: "المصحف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "حفص عن عاصم"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": theme === "night" ? "المظهر النهاري" : "المظهر الليلي",
							onClick: () => setTheme(theme === "night" ? "day" : "night"),
							className: "grid h-11 w-11 place-items-center",
							children: theme === "night" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "الإعدادات",
							onClick: () => setSettings(true),
							className: "grid h-11 w-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-2xl flex-col gap-5 px-4 pt-5 pb-40",
				children: [
					hydrated && last && lastMeta && lastPage && lastJuz ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/read/$surah",
						params: { surah: String(last.s) },
						search: { a: last.a },
						className: "block rounded-2xl border border-line bg-surface px-5 py-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gold",
								children: "تابع القراءة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-2xl font-semibold",
								children: ["سورة ", lastMeta.ar]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"الآية ",
									toArabicDigits(last.a),
									" · الصفحة ",
									toArabicDigits(lastPage),
									" · الجزء ",
									toArabicDigits(lastJuz)
								]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/read/$surah",
						params: { surah: "1" },
						search: { a: 1 },
						className: "block rounded-2xl border border-line bg-surface px-5 py-6 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "basmala text-3xl text-gold",
							children: BISMILLAH
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "ابدأ التلاوة من سورة الفاتحة"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "scroller",
						children: QUICK.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/read/$surah",
							params: { surah: String(item.s) },
							search: { a: item.a },
							className: "shrink-0 rounded-full border border-line bg-surface px-4 py-2 text-sm",
							children: item.label
						}, item.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						onSubmit: (event) => {
							event.preventDefault();
							const exact = surahHits.length === 1 ? surahHits[0] : void 0;
							if (exact) navigate({
								to: "/read/$surah",
								params: { surah: String(exact.i) },
								search: { a: 1 }
							});
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-12 items-center gap-2 rounded-xl border border-line bg-surface px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (event) => setQuery(event.target.value),
								placeholder: "ابحث باسم السورة أو بنص الآية",
								className: "h-11 w-full bg-transparent text-sm text-fg outline-none placeholder:text-faint",
								enterKeyHint: "search"
							})]
						})
					}),
					!searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 rounded-xl bg-surface-2 p-1",
						children: [
							["surah", "السور"],
							["juz", "الأجزاء"],
							["marks", "المحفوظات"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": tab === id,
							onClick: () => setTab(id),
							className: "min-h-11 rounded-lg text-sm font-medium " + (tab === id ? "bg-bg text-fg" : "text-muted"),
							children: label
						}, id))
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-surface px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: retry,
							className: "mt-2 text-gold",
							children: "إعادة المحاولة"
						})]
					}) : null,
					searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-2 text-xs text-muted",
								children: "السور"
							}),
							surahHits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "لا توجد سورة بهذا الاسم."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahList, { items: surahHits }),
							query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-5 mb-2 text-xs text-muted",
									children: "في الآيات"
								}),
								!text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "يتم تحضير نص المصحف للبحث…"
								}) : null,
								text && ayahHits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "لا توجد آيات مطابقة."
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-col",
									children: ayahHits.map((hit) => {
										const meta = surahById(hit.s);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/read/$surah",
											params: { surah: String(hit.s) },
											search: { a: hit.a },
											className: "border-b border-line py-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-gold",
												children: [
													meta?.ar,
													" · ",
													toArabicDigits(hit.a)
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "quran-text line-clamp-2 text-lg",
												children: hit.text
											})]
										}, `${hit.s}-${hit.a}`);
									})
								})
							] }) : null
						]
					}) : null,
					!searching && tab === "surah" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahList, { items: filterSurahs("") }) : null,
					!searching && tab === "juz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col",
						children: juz.map((item, index) => {
							const meta = surahById(item.s);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/read/$surah",
								params: { surah: String(item.s) },
								search: { a: item.a },
								className: "flex min-h-16 items-center justify-between gap-3 border-b border-line py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block font-medium",
									children: ["الجزء ", toArabicDigits(index + 1)]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-sm text-muted",
									children: [
										"من ",
										meta?.ar,
										" · الآية ",
										toArabicDigits(item.a)
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-faint",
									children: ["ص ", toArabicDigits(pageOf(globalIndex(item.s, item.a)))]
								})]
							}, index);
						})
					}) : null,
					!searching && tab === "marks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col",
						children: bookmarks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-xl border border-line bg-surface px-4 py-6 text-sm text-muted",
							children: "لم تحفظ آيات بعد. افتح سورة، ثم اضغط علامة الحفظ في شريط التلاوة."
						}) : bookmarks.map((mark) => {
							const meta = surahById(mark.s);
							const preview = text?.[mark.s - 1]?.[mark.a - 1];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2 border-b border-line py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/read/$surah",
									params: { surah: String(mark.s) },
									search: { a: mark.a },
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-medium",
										children: [
											meta?.ar,
											" · الآية ",
											toArabicDigits(mark.a)
										]
									}), preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "quran-text line-clamp-2 text-lg text-muted",
										children: preview
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "إزالة من المحفوظات",
									onClick: () => toggleBookmark(mark.s, mark.a),
									className: "grid h-11 w-11 shrink-0 place-items-center text-gold",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
										className: "size-5",
										fill: "currentColor"
									})
								})]
							}, `${mark.s}-${mark.a}`);
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-2 text-center text-xs text-faint",
						children: "نص المصحف برواية حفص عن عاصم"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerDock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSheet, {
				open: settings,
				onClose: () => setSettings(false)
			})
		]
	});
}
function SurahList({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col",
		children: items.map((surah) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/read/$surah",
			params: { surah: String(surah.i) },
			search: { a: 1 },
			className: "flex min-h-16 items-center gap-3 border-b border-line py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-11 w-11 shrink-0 place-items-center rounded-lg border border-line text-sm font-medium text-gold",
				children: toArabicDigits(surah.i)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-lg font-semibold leading-tight",
					children: surah.ar
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-sm text-muted",
					children: [
						placeLabel(surah.place),
						" · ",
						toArabicDigits(surah.n),
						" آيات"
					]
				})]
			})]
		}, surah.i))
	});
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M12 2.2 14.1 9.9 21.8 12 14.1 14.1 12 21.8 9.9 14.1 2.2 12 9.9 9.9Z"
		})
	});
}
var SplitComponent = HomeView;
//#endregion
export { SplitComponent as component };
