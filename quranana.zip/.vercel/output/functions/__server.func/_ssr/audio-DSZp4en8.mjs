import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, p as useRouterState, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Play, f as ChevronRight, l as Pause, m as Bookmark, o as Repeat, p as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audio-DSZp4en8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var text_default = "/assets/text-CBeMZT9p.json";
var surahs = [
	{
		"i": 1,
		"ar": "الفاتحة",
		"en": "Al-Fatihah",
		"place": "makkah",
		"n": 7,
		"bismillah": false,
		"page": 1
	},
	{
		"i": 2,
		"ar": "البقرة",
		"en": "Al-Baqarah",
		"place": "madinah",
		"n": 286,
		"bismillah": true,
		"page": 2
	},
	{
		"i": 3,
		"ar": "آل عمران",
		"en": "Ali 'Imran",
		"place": "madinah",
		"n": 200,
		"bismillah": true,
		"page": 50
	},
	{
		"i": 4,
		"ar": "النساء",
		"en": "An-Nisa",
		"place": "madinah",
		"n": 176,
		"bismillah": true,
		"page": 77
	},
	{
		"i": 5,
		"ar": "المائدة",
		"en": "Al-Ma'idah",
		"place": "madinah",
		"n": 120,
		"bismillah": true,
		"page": 106
	},
	{
		"i": 6,
		"ar": "الأنعام",
		"en": "Al-An'am",
		"place": "makkah",
		"n": 165,
		"bismillah": true,
		"page": 128
	},
	{
		"i": 7,
		"ar": "الأعراف",
		"en": "Al-A'raf",
		"place": "makkah",
		"n": 206,
		"bismillah": true,
		"page": 151
	},
	{
		"i": 8,
		"ar": "الأنفال",
		"en": "Al-Anfal",
		"place": "madinah",
		"n": 75,
		"bismillah": true,
		"page": 177
	},
	{
		"i": 9,
		"ar": "التوبة",
		"en": "At-Tawbah",
		"place": "madinah",
		"n": 129,
		"bismillah": false,
		"page": 187
	},
	{
		"i": 10,
		"ar": "يونس",
		"en": "Yunus",
		"place": "makkah",
		"n": 109,
		"bismillah": true,
		"page": 208
	},
	{
		"i": 11,
		"ar": "هود",
		"en": "Hud",
		"place": "makkah",
		"n": 123,
		"bismillah": true,
		"page": 221
	},
	{
		"i": 12,
		"ar": "يوسف",
		"en": "Yusuf",
		"place": "makkah",
		"n": 111,
		"bismillah": true,
		"page": 235
	},
	{
		"i": 13,
		"ar": "الرعد",
		"en": "Ar-Ra'd",
		"place": "madinah",
		"n": 43,
		"bismillah": true,
		"page": 249
	},
	{
		"i": 14,
		"ar": "ابراهيم",
		"en": "Ibrahim",
		"place": "makkah",
		"n": 52,
		"bismillah": true,
		"page": 255
	},
	{
		"i": 15,
		"ar": "الحجر",
		"en": "Al-Hijr",
		"place": "makkah",
		"n": 99,
		"bismillah": true,
		"page": 262
	},
	{
		"i": 16,
		"ar": "النحل",
		"en": "An-Nahl",
		"place": "makkah",
		"n": 128,
		"bismillah": true,
		"page": 267
	},
	{
		"i": 17,
		"ar": "الإسراء",
		"en": "Al-Isra",
		"place": "makkah",
		"n": 111,
		"bismillah": true,
		"page": 282
	},
	{
		"i": 18,
		"ar": "الكهف",
		"en": "Al-Kahf",
		"place": "makkah",
		"n": 110,
		"bismillah": true,
		"page": 293
	},
	{
		"i": 19,
		"ar": "مريم",
		"en": "Maryam",
		"place": "makkah",
		"n": 98,
		"bismillah": true,
		"page": 305
	},
	{
		"i": 20,
		"ar": "طه",
		"en": "Taha",
		"place": "makkah",
		"n": 135,
		"bismillah": true,
		"page": 312
	},
	{
		"i": 21,
		"ar": "الأنبياء",
		"en": "Al-Anbya",
		"place": "makkah",
		"n": 112,
		"bismillah": true,
		"page": 322
	},
	{
		"i": 22,
		"ar": "الحج",
		"en": "Al-Hajj",
		"place": "madinah",
		"n": 78,
		"bismillah": true,
		"page": 332
	},
	{
		"i": 23,
		"ar": "المؤمنون",
		"en": "Al-Mu'minun",
		"place": "makkah",
		"n": 118,
		"bismillah": true,
		"page": 342
	},
	{
		"i": 24,
		"ar": "النور",
		"en": "An-Nur",
		"place": "madinah",
		"n": 64,
		"bismillah": true,
		"page": 350
	},
	{
		"i": 25,
		"ar": "الفرقان",
		"en": "Al-Furqan",
		"place": "makkah",
		"n": 77,
		"bismillah": true,
		"page": 359
	},
	{
		"i": 26,
		"ar": "الشعراء",
		"en": "Ash-Shu'ara",
		"place": "makkah",
		"n": 227,
		"bismillah": true,
		"page": 367
	},
	{
		"i": 27,
		"ar": "النمل",
		"en": "An-Naml",
		"place": "makkah",
		"n": 93,
		"bismillah": true,
		"page": 377
	},
	{
		"i": 28,
		"ar": "القصص",
		"en": "Al-Qasas",
		"place": "makkah",
		"n": 88,
		"bismillah": true,
		"page": 385
	},
	{
		"i": 29,
		"ar": "العنكبوت",
		"en": "Al-'Ankabut",
		"place": "makkah",
		"n": 69,
		"bismillah": true,
		"page": 396
	},
	{
		"i": 30,
		"ar": "الروم",
		"en": "Ar-Rum",
		"place": "makkah",
		"n": 60,
		"bismillah": true,
		"page": 404
	},
	{
		"i": 31,
		"ar": "لقمان",
		"en": "Luqman",
		"place": "makkah",
		"n": 34,
		"bismillah": true,
		"page": 411
	},
	{
		"i": 32,
		"ar": "السجدة",
		"en": "As-Sajdah",
		"place": "makkah",
		"n": 30,
		"bismillah": true,
		"page": 415
	},
	{
		"i": 33,
		"ar": "الأحزاب",
		"en": "Al-Ahzab",
		"place": "madinah",
		"n": 73,
		"bismillah": true,
		"page": 418
	},
	{
		"i": 34,
		"ar": "سبإ",
		"en": "Saba",
		"place": "makkah",
		"n": 54,
		"bismillah": true,
		"page": 428
	},
	{
		"i": 35,
		"ar": "فاطر",
		"en": "Fatir",
		"place": "makkah",
		"n": 45,
		"bismillah": true,
		"page": 434
	},
	{
		"i": 36,
		"ar": "يس",
		"en": "Ya-Sin",
		"place": "makkah",
		"n": 83,
		"bismillah": true,
		"page": 440
	},
	{
		"i": 37,
		"ar": "الصافات",
		"en": "As-Saffat",
		"place": "makkah",
		"n": 182,
		"bismillah": true,
		"page": 446
	},
	{
		"i": 38,
		"ar": "ص",
		"en": "Sad",
		"place": "makkah",
		"n": 88,
		"bismillah": true,
		"page": 453
	},
	{
		"i": 39,
		"ar": "الزمر",
		"en": "Az-Zumar",
		"place": "makkah",
		"n": 75,
		"bismillah": true,
		"page": 458
	},
	{
		"i": 40,
		"ar": "غافر",
		"en": "Ghafir",
		"place": "makkah",
		"n": 85,
		"bismillah": true,
		"page": 467
	},
	{
		"i": 41,
		"ar": "فصلت",
		"en": "Fussilat",
		"place": "makkah",
		"n": 54,
		"bismillah": true,
		"page": 477
	},
	{
		"i": 42,
		"ar": "الشورى",
		"en": "Ash-Shuraa",
		"place": "makkah",
		"n": 53,
		"bismillah": true,
		"page": 483
	},
	{
		"i": 43,
		"ar": "الزخرف",
		"en": "Az-Zukhruf",
		"place": "makkah",
		"n": 89,
		"bismillah": true,
		"page": 489
	},
	{
		"i": 44,
		"ar": "الدخان",
		"en": "Ad-Dukhan",
		"place": "makkah",
		"n": 59,
		"bismillah": true,
		"page": 496
	},
	{
		"i": 45,
		"ar": "الجاثية",
		"en": "Al-Jathiyah",
		"place": "makkah",
		"n": 37,
		"bismillah": true,
		"page": 499
	},
	{
		"i": 46,
		"ar": "الأحقاف",
		"en": "Al-Ahqaf",
		"place": "makkah",
		"n": 35,
		"bismillah": true,
		"page": 502
	},
	{
		"i": 47,
		"ar": "محمد",
		"en": "Muhammad",
		"place": "madinah",
		"n": 38,
		"bismillah": true,
		"page": 507
	},
	{
		"i": 48,
		"ar": "الفتح",
		"en": "Al-Fath",
		"place": "madinah",
		"n": 29,
		"bismillah": true,
		"page": 511
	},
	{
		"i": 49,
		"ar": "الحجرات",
		"en": "Al-Hujurat",
		"place": "madinah",
		"n": 18,
		"bismillah": true,
		"page": 515
	},
	{
		"i": 50,
		"ar": "ق",
		"en": "Qaf",
		"place": "makkah",
		"n": 45,
		"bismillah": true,
		"page": 518
	},
	{
		"i": 51,
		"ar": "الذاريات",
		"en": "Adh-Dhariyat",
		"place": "makkah",
		"n": 60,
		"bismillah": true,
		"page": 520
	},
	{
		"i": 52,
		"ar": "الطور",
		"en": "At-Tur",
		"place": "makkah",
		"n": 49,
		"bismillah": true,
		"page": 523
	},
	{
		"i": 53,
		"ar": "النجم",
		"en": "An-Najm",
		"place": "makkah",
		"n": 62,
		"bismillah": true,
		"page": 526
	},
	{
		"i": 54,
		"ar": "القمر",
		"en": "Al-Qamar",
		"place": "makkah",
		"n": 55,
		"bismillah": true,
		"page": 528
	},
	{
		"i": 55,
		"ar": "الرحمن",
		"en": "Ar-Rahman",
		"place": "madinah",
		"n": 78,
		"bismillah": true,
		"page": 531
	},
	{
		"i": 56,
		"ar": "الواقعة",
		"en": "Al-Waqi'ah",
		"place": "makkah",
		"n": 96,
		"bismillah": true,
		"page": 534
	},
	{
		"i": 57,
		"ar": "الحديد",
		"en": "Al-Hadid",
		"place": "madinah",
		"n": 29,
		"bismillah": true,
		"page": 537
	},
	{
		"i": 58,
		"ar": "المجادلة",
		"en": "Al-Mujadila",
		"place": "madinah",
		"n": 22,
		"bismillah": true,
		"page": 542
	},
	{
		"i": 59,
		"ar": "الحشر",
		"en": "Al-Hashr",
		"place": "madinah",
		"n": 24,
		"bismillah": true,
		"page": 545
	},
	{
		"i": 60,
		"ar": "الممتحنة",
		"en": "Al-Mumtahanah",
		"place": "madinah",
		"n": 13,
		"bismillah": true,
		"page": 549
	},
	{
		"i": 61,
		"ar": "الصف",
		"en": "As-Saf",
		"place": "madinah",
		"n": 14,
		"bismillah": true,
		"page": 551
	},
	{
		"i": 62,
		"ar": "الجمعة",
		"en": "Al-Jumu'ah",
		"place": "madinah",
		"n": 11,
		"bismillah": true,
		"page": 553
	},
	{
		"i": 63,
		"ar": "المنافقون",
		"en": "Al-Munafiqun",
		"place": "madinah",
		"n": 11,
		"bismillah": true,
		"page": 554
	},
	{
		"i": 64,
		"ar": "التغابن",
		"en": "At-Taghabun",
		"place": "madinah",
		"n": 18,
		"bismillah": true,
		"page": 556
	},
	{
		"i": 65,
		"ar": "الطلاق",
		"en": "At-Talaq",
		"place": "madinah",
		"n": 12,
		"bismillah": true,
		"page": 558
	},
	{
		"i": 66,
		"ar": "التحريم",
		"en": "At-Tahrim",
		"place": "madinah",
		"n": 12,
		"bismillah": true,
		"page": 560
	},
	{
		"i": 67,
		"ar": "الملك",
		"en": "Al-Mulk",
		"place": "makkah",
		"n": 30,
		"bismillah": true,
		"page": 562
	},
	{
		"i": 68,
		"ar": "القلم",
		"en": "Al-Qalam",
		"place": "makkah",
		"n": 52,
		"bismillah": true,
		"page": 564
	},
	{
		"i": 69,
		"ar": "الحاقة",
		"en": "Al-Haqqah",
		"place": "makkah",
		"n": 52,
		"bismillah": true,
		"page": 566
	},
	{
		"i": 70,
		"ar": "المعارج",
		"en": "Al-Ma'arij",
		"place": "makkah",
		"n": 44,
		"bismillah": true,
		"page": 568
	},
	{
		"i": 71,
		"ar": "نوح",
		"en": "Nuh",
		"place": "makkah",
		"n": 28,
		"bismillah": true,
		"page": 570
	},
	{
		"i": 72,
		"ar": "الجن",
		"en": "Al-Jinn",
		"place": "makkah",
		"n": 28,
		"bismillah": true,
		"page": 572
	},
	{
		"i": 73,
		"ar": "المزمل",
		"en": "Al-Muzzammil",
		"place": "makkah",
		"n": 20,
		"bismillah": true,
		"page": 574
	},
	{
		"i": 74,
		"ar": "المدثر",
		"en": "Al-Muddaththir",
		"place": "makkah",
		"n": 56,
		"bismillah": true,
		"page": 575
	},
	{
		"i": 75,
		"ar": "القيامة",
		"en": "Al-Qiyamah",
		"place": "makkah",
		"n": 40,
		"bismillah": true,
		"page": 577
	},
	{
		"i": 76,
		"ar": "الانسان",
		"en": "Al-Insan",
		"place": "madinah",
		"n": 31,
		"bismillah": true,
		"page": 578
	},
	{
		"i": 77,
		"ar": "المرسلات",
		"en": "Al-Mursalat",
		"place": "makkah",
		"n": 50,
		"bismillah": true,
		"page": 580
	},
	{
		"i": 78,
		"ar": "النبإ",
		"en": "An-Naba",
		"place": "makkah",
		"n": 40,
		"bismillah": true,
		"page": 582
	},
	{
		"i": 79,
		"ar": "النازعات",
		"en": "An-Nazi'at",
		"place": "makkah",
		"n": 46,
		"bismillah": true,
		"page": 583
	},
	{
		"i": 80,
		"ar": "عبس",
		"en": "'Abasa",
		"place": "makkah",
		"n": 42,
		"bismillah": true,
		"page": 585
	},
	{
		"i": 81,
		"ar": "التكوير",
		"en": "At-Takwir",
		"place": "makkah",
		"n": 29,
		"bismillah": true,
		"page": 586
	},
	{
		"i": 82,
		"ar": "الإنفطار",
		"en": "Al-Infitar",
		"place": "makkah",
		"n": 19,
		"bismillah": true,
		"page": 587
	},
	{
		"i": 83,
		"ar": "المطففين",
		"en": "Al-Mutaffifin",
		"place": "makkah",
		"n": 36,
		"bismillah": true,
		"page": 587
	},
	{
		"i": 84,
		"ar": "الإنشقاق",
		"en": "Al-Inshiqaq",
		"place": "makkah",
		"n": 25,
		"bismillah": true,
		"page": 589
	},
	{
		"i": 85,
		"ar": "البروج",
		"en": "Al-Buruj",
		"place": "makkah",
		"n": 22,
		"bismillah": true,
		"page": 590
	},
	{
		"i": 86,
		"ar": "الطارق",
		"en": "At-Tariq",
		"place": "makkah",
		"n": 17,
		"bismillah": true,
		"page": 591
	},
	{
		"i": 87,
		"ar": "الأعلى",
		"en": "Al-A'la",
		"place": "makkah",
		"n": 19,
		"bismillah": true,
		"page": 591
	},
	{
		"i": 88,
		"ar": "الغاشية",
		"en": "Al-Ghashiyah",
		"place": "makkah",
		"n": 26,
		"bismillah": true,
		"page": 592
	},
	{
		"i": 89,
		"ar": "الفجر",
		"en": "Al-Fajr",
		"place": "makkah",
		"n": 30,
		"bismillah": true,
		"page": 593
	},
	{
		"i": 90,
		"ar": "البلد",
		"en": "Al-Balad",
		"place": "makkah",
		"n": 20,
		"bismillah": true,
		"page": 594
	},
	{
		"i": 91,
		"ar": "الشمس",
		"en": "Ash-Shams",
		"place": "makkah",
		"n": 15,
		"bismillah": true,
		"page": 595
	},
	{
		"i": 92,
		"ar": "الليل",
		"en": "Al-Layl",
		"place": "makkah",
		"n": 21,
		"bismillah": true,
		"page": 595
	},
	{
		"i": 93,
		"ar": "الضحى",
		"en": "Ad-Duhaa",
		"place": "makkah",
		"n": 11,
		"bismillah": true,
		"page": 596
	},
	{
		"i": 94,
		"ar": "الشرح",
		"en": "Ash-Sharh",
		"place": "makkah",
		"n": 8,
		"bismillah": true,
		"page": 596
	},
	{
		"i": 95,
		"ar": "التين",
		"en": "At-Tin",
		"place": "makkah",
		"n": 8,
		"bismillah": true,
		"page": 597
	},
	{
		"i": 96,
		"ar": "العلق",
		"en": "Al-'Alaq",
		"place": "makkah",
		"n": 19,
		"bismillah": true,
		"page": 597
	},
	{
		"i": 97,
		"ar": "القدر",
		"en": "Al-Qadr",
		"place": "makkah",
		"n": 5,
		"bismillah": true,
		"page": 598
	},
	{
		"i": 98,
		"ar": "البينة",
		"en": "Al-Bayyinah",
		"place": "madinah",
		"n": 8,
		"bismillah": true,
		"page": 598
	},
	{
		"i": 99,
		"ar": "الزلزلة",
		"en": "Az-Zalzalah",
		"place": "madinah",
		"n": 8,
		"bismillah": true,
		"page": 599
	},
	{
		"i": 100,
		"ar": "العاديات",
		"en": "Al-'Adiyat",
		"place": "makkah",
		"n": 11,
		"bismillah": true,
		"page": 599
	},
	{
		"i": 101,
		"ar": "القارعة",
		"en": "Al-Qari'ah",
		"place": "makkah",
		"n": 11,
		"bismillah": true,
		"page": 600
	},
	{
		"i": 102,
		"ar": "التكاثر",
		"en": "At-Takathur",
		"place": "makkah",
		"n": 8,
		"bismillah": true,
		"page": 600
	},
	{
		"i": 103,
		"ar": "العصر",
		"en": "Al-'Asr",
		"place": "makkah",
		"n": 3,
		"bismillah": true,
		"page": 601
	},
	{
		"i": 104,
		"ar": "الهمزة",
		"en": "Al-Humazah",
		"place": "makkah",
		"n": 9,
		"bismillah": true,
		"page": 601
	},
	{
		"i": 105,
		"ar": "الفيل",
		"en": "Al-Fil",
		"place": "makkah",
		"n": 5,
		"bismillah": true,
		"page": 601
	},
	{
		"i": 106,
		"ar": "قريش",
		"en": "Quraysh",
		"place": "makkah",
		"n": 4,
		"bismillah": true,
		"page": 602
	},
	{
		"i": 107,
		"ar": "الماعون",
		"en": "Al-Ma'un",
		"place": "makkah",
		"n": 7,
		"bismillah": true,
		"page": 602
	},
	{
		"i": 108,
		"ar": "الكوثر",
		"en": "Al-Kawthar",
		"place": "makkah",
		"n": 3,
		"bismillah": true,
		"page": 602
	},
	{
		"i": 109,
		"ar": "الكافرون",
		"en": "Al-Kafirun",
		"place": "makkah",
		"n": 6,
		"bismillah": true,
		"page": 603
	},
	{
		"i": 110,
		"ar": "النصر",
		"en": "An-Nasr",
		"place": "madinah",
		"n": 3,
		"bismillah": true,
		"page": 603
	},
	{
		"i": 111,
		"ar": "المسد",
		"en": "Al-Masad",
		"place": "makkah",
		"n": 5,
		"bismillah": true,
		"page": 603
	},
	{
		"i": 112,
		"ar": "الإخلاص",
		"en": "Al-Ikhlas",
		"place": "makkah",
		"n": 4,
		"bismillah": true,
		"page": 604
	},
	{
		"i": 113,
		"ar": "الفلق",
		"en": "Al-Falaq",
		"place": "makkah",
		"n": 5,
		"bismillah": true,
		"page": 604
	},
	{
		"i": 114,
		"ar": "الناس",
		"en": "An-Nas",
		"place": "makkah",
		"n": 6,
		"bismillah": true,
		"page": 604
	}
];
var pageStart = [
	0,
	7,
	12,
	23,
	31,
	36,
	44,
	55,
	64,
	68,
	76,
	83,
	90,
	95,
	100,
	108,
	112,
	119,
	126,
	133,
	141,
	148,
	152,
	160,
	170,
	176,
	183,
	188,
	193,
	197,
	203,
	209,
	217,
	222,
	226,
	231,
	237,
	240,
	244,
	252,
	255,
	259,
	263,
	266,
	271,
	276,
	281,
	288,
	289,
	293,
	302,
	308,
	315,
	322,
	330,
	338,
	345,
	354,
	363,
	370,
	376,
	384,
	393,
	401,
	408,
	414,
	425,
	433,
	441,
	446,
	450,
	458,
	466,
	473,
	479,
	487,
	493,
	499,
	504,
	507,
	512,
	516,
	519,
	526,
	530,
	537,
	544,
	552,
	558,
	567,
	572,
	579,
	584,
	587,
	594,
	598,
	606,
	614,
	620,
	627,
	633,
	640,
	647,
	655,
	663,
	668,
	671,
	674,
	678,
	682,
	686,
	692,
	700,
	705,
	710,
	714,
	719,
	726,
	733,
	739,
	745,
	751,
	758,
	764,
	772,
	777,
	782,
	789,
	797,
	807,
	816,
	824,
	833,
	841,
	848,
	857,
	862,
	870,
	879,
	883,
	890,
	899,
	907,
	913,
	920,
	926,
	931,
	935,
	940,
	946,
	954,
	965,
	976,
	984,
	991,
	997,
	1005,
	1011,
	1021,
	1027,
	1035,
	1041,
	1049,
	1058,
	1074,
	1084,
	1091,
	1097,
	1103,
	1109,
	1113,
	1117,
	1124,
	1132,
	1141,
	1149,
	1160,
	1168,
	1176,
	1185,
	1193,
	1200,
	1205,
	1212,
	1221,
	1229,
	1235,
	1241,
	1248,
	1255,
	1261,
	1266,
	1271,
	1275,
	1282,
	1289,
	1296,
	1303,
	1307,
	1314,
	1321,
	1328,
	1334,
	1341,
	1346,
	1352,
	1357,
	1364,
	1370,
	1378,
	1384,
	1389,
	1397,
	1406,
	1417,
	1425,
	1434,
	1442,
	1452,
	1461,
	1470,
	1478,
	1485,
	1492,
	1501,
	1510,
	1518,
	1526,
	1535,
	1544,
	1554,
	1561,
	1570,
	1581,
	1590,
	1600,
	1610,
	1618,
	1626,
	1633,
	1639,
	1648,
	1659,
	1665,
	1674,
	1682,
	1691,
	1699,
	1707,
	1712,
	1720,
	1725,
	1735,
	1741,
	1749,
	1755,
	1760,
	1768,
	1774,
	1783,
	1792,
	1802,
	1817,
	1833,
	1853,
	1872,
	1892,
	1907,
	1915,
	1927,
	1935,
	1943,
	1955,
	1965,
	1973,
	1980,
	1988,
	1994,
	2003,
	2011,
	2019,
	2029,
	2036,
	2046,
	2056,
	2067,
	2078,
	2087,
	2095,
	2104,
	2115,
	2125,
	2133,
	2144,
	2155,
	2160,
	2167,
	2174,
	2185,
	2193,
	2201,
	2214,
	2223,
	2237,
	2250,
	2261,
	2275,
	2288,
	2301,
	2314,
	2326,
	2345,
	2360,
	2385,
	2399,
	2412,
	2424,
	2435,
	2446,
	2461,
	2473,
	2483,
	2493,
	2507,
	2518,
	2527,
	2540,
	2555,
	2564,
	2573,
	2584,
	2595,
	2600,
	2610,
	2618,
	2625,
	2633,
	2641,
	2650,
	2659,
	2667,
	2673,
	2690,
	2700,
	2715,
	2732,
	2747,
	2762,
	2777,
	2791,
	2801,
	2811,
	2818,
	2822,
	2827,
	2834,
	2844,
	2849,
	2852,
	2857,
	2866,
	2875,
	2887,
	2898,
	2910,
	2922,
	2932,
	2951,
	2971,
	2992,
	3015,
	3043,
	3068,
	3091,
	3115,
	3138,
	3159,
	3172,
	3181,
	3194,
	3203,
	3214,
	3222,
	3235,
	3247,
	3257,
	3265,
	3273,
	3280,
	3287,
	3295,
	3302,
	3311,
	3322,
	3329,
	3336,
	3346,
	3354,
	3363,
	3370,
	3378,
	3385,
	3392,
	3403,
	3414,
	3424,
	3433,
	3441,
	3450,
	3459,
	3469,
	3480,
	3488,
	3497,
	3503,
	3514,
	3523,
	3533,
	3539,
	3548,
	3555,
	3563,
	3568,
	3576,
	3583,
	3587,
	3595,
	3606,
	3613,
	3620,
	3628,
	3637,
	3645,
	3654,
	3663,
	3671,
	3678,
	3690,
	3698,
	3704,
	3717,
	3732,
	3745,
	3759,
	3775,
	3788,
	3812,
	3839,
	3864,
	3890,
	3914,
	3941,
	3970,
	3986,
	3996,
	4012,
	4031,
	4053,
	4063,
	4068,
	4079,
	4089,
	4098,
	4105,
	4114,
	4125,
	4132,
	4140,
	4149,
	4158,
	4166,
	4173,
	4182,
	4191,
	4199,
	4210,
	4218,
	4229,
	4238,
	4247,
	4256,
	4264,
	4272,
	4282,
	4287,
	4294,
	4303,
	4316,
	4323,
	4335,
	4347,
	4358,
	4372,
	4385,
	4398,
	4414,
	4432,
	4453,
	4473,
	4486,
	4495,
	4505,
	4515,
	4524,
	4530,
	4538,
	4545,
	4556,
	4564,
	4574,
	4583,
	4592,
	4598,
	4606,
	4611,
	4616,
	4623,
	4630,
	4645,
	4665,
	4681,
	4705,
	4726,
	4749,
	4766,
	4784,
	4810,
	4828,
	4852,
	4873,
	4895,
	4917,
	4941,
	4968,
	4995,
	5029,
	5055,
	5078,
	5086,
	5093,
	5099,
	5104,
	5110,
	5115,
	5125,
	5129,
	5135,
	5142,
	5150,
	5155,
	5161,
	5168,
	5177,
	5185,
	5192,
	5199,
	5208,
	5217,
	5222,
	5229,
	5236,
	5241,
	5253,
	5267,
	5286,
	5313,
	5331,
	5357,
	5385,
	5414,
	5429,
	5447,
	5460,
	5475,
	5494,
	5512,
	5542,
	5570,
	5596,
	5616,
	5641,
	5672,
	5702,
	5727,
	5758,
	5800,
	5829,
	5854,
	5882,
	5909,
	5931,
	5963,
	5993,
	6016,
	6043,
	6072,
	6098,
	6125,
	6137,
	6155,
	6176,
	6193,
	6207,
	6221
];
var juz = [
	{
		"s": 1,
		"a": 1
	},
	{
		"s": 2,
		"a": 142
	},
	{
		"s": 2,
		"a": 253
	},
	{
		"s": 3,
		"a": 93
	},
	{
		"s": 4,
		"a": 24
	},
	{
		"s": 4,
		"a": 148
	},
	{
		"s": 5,
		"a": 82
	},
	{
		"s": 6,
		"a": 111
	},
	{
		"s": 7,
		"a": 88
	},
	{
		"s": 8,
		"a": 41
	},
	{
		"s": 9,
		"a": 93
	},
	{
		"s": 11,
		"a": 6
	},
	{
		"s": 12,
		"a": 53
	},
	{
		"s": 15,
		"a": 1
	},
	{
		"s": 17,
		"a": 1
	},
	{
		"s": 18,
		"a": 75
	},
	{
		"s": 21,
		"a": 1
	},
	{
		"s": 23,
		"a": 1
	},
	{
		"s": 25,
		"a": 21
	},
	{
		"s": 27,
		"a": 56
	},
	{
		"s": 29,
		"a": 46
	},
	{
		"s": 33,
		"a": 31
	},
	{
		"s": 36,
		"a": 28
	},
	{
		"s": 39,
		"a": 32
	},
	{
		"s": 41,
		"a": 47
	},
	{
		"s": 46,
		"a": 1
	},
	{
		"s": 51,
		"a": 31
	},
	{
		"s": 58,
		"a": 1
	},
	{
		"s": 67,
		"a": 1
	},
	{
		"s": 78,
		"a": 1
	}
];
var sajda = [
	[7, 206],
	[13, 15],
	[16, 50],
	[17, 109],
	[19, 58],
	[22, 18],
	[22, 77],
	[25, 60],
	[27, 26],
	[32, 15],
	[38, 24],
	[41, 38],
	[53, 62],
	[84, 21],
	[96, 19]
];
var surahOffset = (() => {
	const out = [];
	let acc = 0;
	for (const s of surahs) {
		out.push(acc);
		acc += s.n;
	}
	return out;
})();
var BISMILLAH = "بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ";
var RECITERS = [
	{
		id: "ar.mahermuaiqly",
		name: "ماهر المعيقلي",
		bitrate: 128
	},
	{
		id: "ar.abdurrahmaansudais",
		name: "عبد الرحمن السديس",
		bitrate: 64
	},
	{
		id: "ar.saoodshuraym",
		name: "سعود الشريم",
		bitrate: 64
	},
	{
		id: "ar.hudhaify",
		name: "علي الحذيفي",
		bitrate: 128
	},
	{
		id: "ar.alafasy",
		name: "مشاري العفاسي",
		bitrate: 128
	},
	{
		id: "ar.shaatree",
		name: "أبو بكر الشاطري",
		bitrate: 128
	},
	{
		id: "ar.minshawi",
		name: "محمد صديق المنشاوي",
		bitrate: 128
	},
	{
		id: "ar.husary",
		name: "محمود خليل الحصري",
		bitrate: 128
	},
	{
		id: "ar.abdulbasitmurattal",
		name: "عبد الباسط عبد الصمد",
		bitrate: 64
	}
];
var sajdaKeys = new Set(sajda.map(([s, a]) => s * 1e3 + a));
var juzGlobal = juz.map((j) => surahOffset[j.s - 1] + (j.a - 1));
function toArabicDigits(n) {
	return String(n).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]);
}
function fromArabicDigits(value) {
	return value.replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}
function normalizeArabic(input) {
	return input.replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF\u0640]/g, "").replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, "").replace(/[أإآٱ\u0671]/g, "ا").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/ة/g, "ه").replace(/\s+/g, " ").trim();
}
function placeLabel(place) {
	return place === "makkah" ? "مكية" : "مدنية";
}
function globalIndex(s, a) {
	return surahOffset[s - 1] + (a - 1);
}
function locate(g) {
	let lo = 0;
	let hi = surahs.length - 1;
	while (lo <= hi) {
		const mid = lo + hi >> 1;
		const start = surahOffset[mid];
		const end = start + surahs[mid].n;
		if (g < start) hi = mid - 1;
		else if (g >= end) lo = mid + 1;
		else return {
			s: surahs[mid].i,
			a: g - start + 1
		};
	}
	return {
		s: 114,
		a: surahs[113].n
	};
}
function pageOf(g) {
	let lo = 0;
	let hi = pageStart.length - 1;
	let ans = 0;
	while (lo <= hi) {
		const mid = lo + hi >> 1;
		if (pageStart[mid] <= g) {
			ans = mid;
			lo = mid + 1;
		} else hi = mid - 1;
	}
	return ans + 1;
}
function juzOf(g) {
	let ans = 1;
	for (let i = 0; i < juzGlobal.length; i++) if (juzGlobal[i] <= g) ans = i + 1;
	else break;
	return ans;
}
function isSajda(s, a) {
	return sajdaKeys.has(s * 1e3 + a);
}
function audioUrl(reciterId, globalOne) {
	const reciter = RECITERS.find((item) => item.id === reciterId) ?? RECITERS[0];
	return `https://cdn.islamic.network/quran/audio/${reciter.bitrate}/${reciter.id}/${globalOne}.mp3`;
}
function reciterName(id) {
	return RECITERS.find((item) => item.id === id)?.name ?? RECITERS[0].name;
}
function formatRate(rate) {
	return {
		"0.75": "٠٫٧٥×",
		"1": "١×",
		"1.25": "١٫٢٥×",
		"1.5": "١٫٥×"
	}[String(rate)] ?? `${rate}×`;
}
function surahById(id) {
	return surahs[id - 1];
}
function stripDefinite(value) {
	return value.replace(/^ال/, "");
}
function filterSurahs(query) {
	const raw = fromArabicDigits(query).trim();
	if (!raw) return surahs;
	const arabic = normalizeArabic(raw).replace(/\s/g, "");
	const latin = raw.toLowerCase().replace(/['’\-]/g, "");
	const digits = /^\d+$/.test(raw) ? Number(raw) : null;
	return surahs.filter((surah) => {
		if (digits !== null && (surah.i === digits || String(surah.i).startsWith(raw))) return true;
		const name = normalizeArabic(surah.ar).replace(/\s/g, "");
		if (arabic && (name.includes(arabic) || stripDefinite(name).includes(stripDefinite(arabic)))) return true;
		if (latin.length >= 2 && surah.en.toLowerCase().replace(/['’\-]/g, "").includes(latin)) return true;
		return false;
	});
}
var normCache = null;
function indexText(text) {
	normCache = text.map((surah) => surah.map((ayah) => normalizeArabic(ayah).replace(/\s/g, "")));
}
var SEARCH_SKIP = /* @__PURE__ */ new Set([
	"ايه",
	"سوره",
	"جزء"
]);
function searchAyahs(text, query, limit = 40) {
	const words = normalizeArabic(query).split(" ").map((word) => word.replace(/^ال(?=.{3,})/, "")).filter((word) => word.length >= 2 && !SEARCH_SKIP.has(word));
	if (!words.length) return [];
	if (!normCache || normCache.length !== text.length) indexText(text);
	const hits = [];
	const cache = normCache;
	if (!cache) return hits;
	for (let s = 0; s < cache.length; s++) {
		const surah = cache[s];
		for (let a = 0; a < surah.length; a++) {
			if (!words.every((word) => surah[a].includes(word))) continue;
			hits.push({
				s: s + 1,
				a: a + 1,
				text: text[s][a]
			});
			if (hits.length >= limit) return hits;
		}
	}
	return hits;
}
var textPromise = null;
function loadText() {
	if (!textPromise) {
		const pending = fetch(text_default).then(async (res) => {
			if (!res.ok) throw new Error("تعذّر تحميل نص المصحف");
			const data = await res.json();
			if (!Array.isArray(data) || data.length !== 114) throw new Error("نص المصحف غير مكتمل");
			indexText(data);
			return data;
		});
		textPromise = pending;
		pending.catch(() => {
			if (textPromise === pending) textPromise = null;
		});
	}
	return textPromise;
}
var RATES = [
	.75,
	1,
	1.25,
	1.5
];
var useMushaf = create()(persist((set, get) => ({
	theme: "night",
	fontSize: 34,
	reciter: "ar.mahermuaiqly",
	rate: 1,
	showPages: true,
	follow: true,
	autoNextSurah: true,
	repeat: false,
	last: null,
	bookmarks: [],
	setTheme: (theme) => set({ theme }),
	setFontSize: (size) => set({ fontSize: Math.min(56, Math.max(24, size)) }),
	setReciter: (reciter) => set({ reciter }),
	setRate: (rate) => set({ rate }),
	cycleRate: () => {
		const current = get().rate;
		set({ rate: RATES[(RATES.indexOf(current) + 1) % RATES.length] ?? 1 });
	},
	togglePages: () => set({ showPages: !get().showPages }),
	toggleFollow: () => set({ follow: !get().follow }),
	toggleAutoNext: () => set({ autoNextSurah: !get().autoNextSurah }),
	toggleRepeat: () => set({ repeat: !get().repeat }),
	setLast: (s, a) => set({ last: {
		s,
		a
	} }),
	toggleBookmark: (s, a) => {
		const current = get().bookmarks;
		const index = current.findIndex((item) => item.s === s && item.a === a);
		if (index >= 0) {
			set({ bookmarks: current.filter((_, i) => i !== index) });
			return;
		}
		set({ bookmarks: [{
			s,
			a,
			t: Date.now()
		}, ...current].slice(0, 300) });
	}
}), {
	name: "mushaf",
	version: 1
}));
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setHydrated(useMushaf.persist.hasHydrated());
		return useMushaf.persist.onFinishHydration(() => setHydrated(true));
	}, []);
	return hydrated;
}
function useApplyTheme() {
	const theme = useMushaf((state) => state.theme);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
		document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", theme === "day" ? "#f3ecdf" : "#0e1411");
	}, [theme]);
}
var AudioContext = (0, import_react.createContext)(null);
function useAudio() {
	const ctx = (0, import_react.useContext)(AudioContext);
	if (!ctx) throw new Error("مشغّل التلاوة غير جاهز");
	return ctx;
}
function QuranAudioProvider({ children }) {
	const navigate = useNavigate();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const [current, setCurrent] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const audioRef = (0, import_react.useRef)(null);
	const currentRef = (0, import_react.useRef)(null);
	const navigateRef = (0, import_react.useRef)(navigate);
	const routeSurahRef = (0, import_react.useRef)(null);
	const playRef = (0, import_react.useRef)(() => {});
	currentRef.current = current;
	navigateRef.current = navigate;
	routeSurahRef.current = Number(pathname.match(/\/read\/(\d+)/)?.[1] ?? "") || null;
	const play = (0, import_react.useCallback)((s, a) => {
		const audio = audioRef.current;
		if (!audio) return;
		const surah = surahById(s);
		if (!surah || a < 1 || a > surah.n) return;
		const { reciter, rate, setLast } = useMushaf.getState();
		const url = audioUrl(reciter, globalIndex(s, a) + 1);
		setError(null);
		setCurrent({
			s,
			a
		});
		setLast(s, a);
		if (routeSurahRef.current && routeSurahRef.current !== s) navigateRef.current({
			to: "/read/$surah",
			params: { surah: String(s) },
			search: { a },
			replace: true
		});
		audio.src = url;
		audio.playbackRate = rate;
		audio.play().then(() => setPlaying(true), () => {
			setPlaying(false);
			setError("تعذّر بدء التلاوة. حاول مرة أخرى.");
		});
	}, []);
	playRef.current = play;
	const step = (0, import_react.useCallback)((dir, manual) => {
		const cur = currentRef.current;
		if (!cur) return;
		const g = globalIndex(cur.s, cur.a) + dir;
		if (g < 0 || g >= 6236) {
			audioRef.current?.pause();
			setPlaying(false);
			return;
		}
		const loc = locate(g);
		if (!manual && dir === 1 && loc.s !== cur.s && !useMushaf.getState().autoNextSurah) {
			audioRef.current?.pause();
			setPlaying(false);
			return;
		}
		playRef.current(loc.s, loc.a);
	}, []);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio) return;
		const onEnded = () => {
			if (useMushaf.getState().repeat) {
				audio.currentTime = 0;
				audio.play().then(() => setPlaying(true), () => setPlaying(false));
				return;
			}
			step(1, false);
		};
		const onError = () => {
			if (!audio.getAttribute("src")) return;
			setPlaying(false);
			setError("تعذّر تحميل صوت هذه الآية.");
		};
		audio.addEventListener("ended", onEnded);
		audio.addEventListener("error", onError);
		return () => {
			audio.pause();
			audio.removeEventListener("ended", onEnded);
			audio.removeEventListener("error", onError);
		};
	}, [step]);
	const reciter = useMushaf((state) => state.reciter);
	const rate = useMushaf((state) => state.rate);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		const cur = currentRef.current;
		if (!audio || !cur) return;
		audio.playbackRate = rate;
		const url = audioUrl(reciter, globalIndex(cur.s, cur.a) + 1);
		if (audio.src.endsWith(`/${globalIndex(cur.s, cur.a) + 1}.mp3`) && audio.src.includes(reciter)) return;
		const wasPlaying = !audio.paused;
		audio.src = url;
		if (wasPlaying) audio.play().catch(() => setPlaying(false));
	}, [reciter, rate]);
	const toggle = (0, import_react.useCallback)(() => {
		const audio = audioRef.current;
		const cur = currentRef.current;
		if (!audio || !cur) return;
		if (!audio.paused) {
			audio.pause();
			setPlaying(false);
			return;
		}
		audio.play().then(() => setPlaying(true), () => {
			setPlaying(false);
			setError("اضغط تشغيل مرة أخرى.");
		});
	}, []);
	const stop = (0, import_react.useCallback)(() => {
		audioRef.current?.pause();
		setPlaying(false);
	}, []);
	const api = (0, import_react.useMemo)(() => ({
		current,
		playing,
		error,
		play,
		toggle,
		next: () => step(1, true),
		prev: () => step(-1, true),
		stop
	}), [
		current,
		playing,
		error,
		play,
		toggle,
		step,
		stop
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AudioContext.Provider, {
		value: api,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
			ref: audioRef,
			preload: "none",
			className: "sr-audio"
		}), children]
	});
}
function PlayerDock({ surah, ayah, bookmarked, copied, onToggleBookmark, onCopy }) {
	const audio = useAudio();
	const reciter = useMushaf((state) => state.reciter);
	const rate = useMushaf((state) => state.rate);
	const repeat = useMushaf((state) => state.repeat);
	const cycleRate = useMushaf((state) => state.cycleRate);
	const toggleRepeat = useMushaf((state) => state.toggleRepeat);
	const target = surah && ayah ? {
		s: surah,
		a: ayah
	} : audio.current;
	if (!target) return null;
	const meta = surahById(target.s);
	const isCurrent = audio.current?.s === target.s && audio.current?.a === target.a && Boolean(audio.current);
	const showFull = Boolean(surah && ayah);
	function playTarget() {
		if (!target) return;
		if (isCurrent) audio.toggle();
		else audio.play(target.s, target.a);
	}
	function go(dir) {
		const base = isCurrent && audio.current ? audio.current : target;
		if (!base) return;
		const g = globalIndex(base.s, base.a) + dir;
		if (g < 0 || g >= 6236) return;
		const loc = locate(g);
		audio.play(loc.s, loc.a);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "dock fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg/95 backdrop-blur",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-2xl flex-col gap-2 px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm font-semibold",
							children: [
								meta?.ar,
								" · الآية ",
								toArabicDigits(target.a)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted",
							children: reciterName(reciter)
						})]
					}), showFull ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: bookmarked ? "إزالة المحفوظ" : "حفظ الآية",
							onClick: onToggleBookmark,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
								className: "size-5",
								fill: bookmarked ? "currentColor" : "none"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: copied ? "نُسخت" : "نسخ الآية",
							onClick: onCopy,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold",
								children: copied ? "تم" : "نسخ"
							})
						})]
					}) : null]
				}),
				audio.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-gold",
					children: audio.error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								label: "الآية السابقة",
								onClick: () => isCurrent ? audio.prev() : go(-1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: playTarget,
								"aria-label": audio.playing && isCurrent ? "إيقاف" : "تشغيل",
								className: "grid h-12 w-12 place-items-center rounded-full bg-gold-fill text-on-gold",
								children: audio.playing && isCurrent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								label: "الآية التالية",
								onClick: () => isCurrent ? audio.next() : go(1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": repeat,
							onClick: toggleRepeat,
							className: "grid h-11 min-w-11 place-items-center rounded-full border border-line px-2 " + (repeat ? "text-gold" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "تكرار الآية"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: cycleRate,
							className: "h-11 min-w-14 rounded-full border border-line px-3 text-sm text-fg",
							children: formatRate(rate)
						})]
					})]
				})
			]
		})
	});
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "grid h-11 min-w-11 place-items-center rounded-full text-fg",
		children
	});
}
//#endregion
export { useMushaf as S, surahById as _, filterSurahs as a, useAudio as b, isSajda as c, loadText as d, locate as f, searchAyahs as g, placeLabel as h, RECITERS as i, juz as l, pageStart as m, PlayerDock as n, fromArabicDigits as o, pageOf as p, QuranAudioProvider as r, globalIndex as s, BISMILLAH as t, juzOf as u, toArabicDigits as v, useHydrated as x, useApplyTheme as y };
