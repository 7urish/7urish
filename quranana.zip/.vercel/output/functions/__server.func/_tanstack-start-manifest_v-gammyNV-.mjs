//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-gammyNV-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/read/$surah"],
		preloads: [
			"/assets/index-Dy5pSGf4.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/audio-Dnp0mDMs.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dy5pSGf4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DAlp21nG.js", "/assets/settings-jmx5GdO4.js"]
	},
	"/read/$surah": {
		filePath: "/workspace/src/routes/read/$surah.tsx",
		children: void 0,
		preloads: ["/assets/_surah-DY4UeBVq.js", "/assets/settings-jmx5GdO4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
