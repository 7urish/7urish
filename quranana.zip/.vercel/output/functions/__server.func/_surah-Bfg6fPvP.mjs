import { i as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { d as Minus, f as ChevronRight, i as Settings, s as Plus } from "./_libs/lucide-react.mjs";
import { S as useMushaf, _ as surahById, b as useAudio, c as isSajda, f as locate, h as placeLabel, m as pageStart, n as PlayerDock, o as fromArabicDigits, p as pageOf, s as globalIndex, t as BISMILLAH, u as juzOf, v as toArabicDigits } from "./_ssr/audio-DSZp4en8.mjs";
import { n as Route } from "./_ssr/router-Be8d0UF_.mjs";
import { n as Sheet, r as useQuranText, t as SettingsSheet } from "./_ssr/settings-CQgHDd5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_surah-Bfg6fPvP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReaderView({ surah, ayah }) {
	const meta = surahById(surah);
	const { text, error, retry } = useQuranText();
	const audio = useAudio();
	const fontSize = useMushaf((state) => state.fontSize);
	const setFontSize = useMushaf((state) => state.setFontSize);
	const showPages = useMushaf((state) => state.showPages);
	const follow = useMushaf((state) => state.follow);
	const setLast = useMushaf((state) => state.setLast);
	const toggleBookmark = useMushaf((state) => state.toggleBookmark);
	const [sel, setSel] = (0, import_react.useState)(ayah);
	const [visible, setVisible] = (0, import_react.useState)(ayah);
	const [settings, setSettings] = (0, import_react.useState)(false);
	const [jumpOpen, setJumpOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const bookmarked = useMushaf((state) => state.bookmarks.some((item) => item.s === surah && item.a === sel));
	const verses = text?.[surah - 1];
	const visibleGlobal = meta ? globalIndex(surah, Math.min(visible, meta.n)) : 0;
	(0, import_react.useEffect)(() => {
		setSel(ayah);
		setVisible(ayah);
		setLast(surah, ayah);
	}, [
		surah,
		ayah,
		setLast
	]);
	(0, import_react.useEffect)(() => {
		if (!verses) return;
		const target = document.getElementById(`ayah-${surah}-${ayah}`);
		if (ayah <= 1) {
			window.scrollTo({ top: 0 });
			return;
		}
		target?.scrollIntoView({ block: "center" });
	}, [
		verses,
		surah,
		ayah
	]);
	(0, import_react.useEffect)(() => {
		if (audio.playing && audio.current?.s === surah) setSel(audio.current.a);
	}, [
		audio.playing,
		audio.current,
		surah
	]);
	(0, import_react.useEffect)(() => {
		if (!follow || !audio.playing || audio.current?.s !== surah) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		document.getElementById(`ayah-${surah}-${audio.current.a}`)?.scrollIntoView({
			block: "center",
			behavior: reduce ? "auto" : "smooth"
		});
	}, [
		audio.current,
		audio.playing,
		follow,
		surah
	]);
	(0, import_react.useEffect)(() => {
		if (!verses) return;
		const nodes = document.querySelectorAll("[data-ayah-row]");
		const observer = new IntersectionObserver((entries) => {
			const top = entries.filter((entry) => entry.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
			const next = Number((top?.target)?.dataset.ayah);
			if (next) setVisible(next);
		}, {
			rootMargin: "-96px 0px -62% 0px",
			threshold: .15
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, [verses, surah]);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setLast(surah, visible), 800);
		return () => window.clearTimeout(timer);
	}, [
		surah,
		visible,
		setLast
	]);
	async function copyAyah() {
		const verse = verses?.[sel - 1];
		if (!verse || !meta) return;
		const payload = `${verse} ﴿${toArabicDigits(sel)}﴾ — ${meta.ar}`;
		try {
			await navigator.clipboard.writeText(payload);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1400);
		} catch {
			setCopied(false);
		}
	}
	if (!meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "هذه السورة غير موجودة." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-4 inline-block text-gold",
			children: "العودة إلى الفهرس"
		})]
	});
	const clamped = Math.min(Math.max(sel, 1), meta.n);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-2xl items-center gap-1 px-2 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							"aria-label": "الفهرس",
							className: "grid h-11 w-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "truncate text-base font-semibold",
								children: ["سورة ", meta.ar]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setJumpOpen(true),
								className: "text-xs text-muted",
								children: [
									"الصفحة ",
									toArabicDigits(pageOf(visibleGlobal)),
									" · الجزء ",
									toArabicDigits(juzOf(visibleGlobal))
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "تصغير الخط",
							onClick: () => setFontSize(fontSize - 2),
							className: "grid h-11 w-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "تكبير الخط",
							onClick: () => setFontSize(fontSize + 2),
							className: "grid h-11 w-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "الإعدادات",
							onClick: () => setSettings(true),
							className: "grid h-11 w-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-2xl px-3 pt-6 pb-44",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-wide text-gold",
								children: "سورة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-3xl font-semibold",
								children: meta.ar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									placeLabel(meta.place),
									" · ",
									toArabicDigits(meta.n),
									" آيات"
								]
							})
						]
					}),
					meta.bismillah ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "basmala mb-6 text-center text-3xl text-gold",
						children: BISMILLAH
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line px-4 py-4 text-center text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: retry,
							className: "mt-3 text-gold",
							children: "إعادة المحاولة"
						})]
					}) : null,
					!verses && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-sm text-muted",
						children: "جاري فتح السورة…"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: { fontSize },
						children: verses?.map((verse, index) => {
							const n = index + 1;
							const g = globalIndex(surah, n);
							const page = pageOf(g);
							const juz = juzOf(g);
							const prevG = n === 1 ? g : g - 1;
							const pageBreak = showPages && n > 1 && page !== pageOf(prevG);
							const juzBreak = showPages && n > 1 && juz !== juzOf(prevG);
							const playing = audio.playing && audio.current?.s === surah && audio.current.a === n;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [pageBreak || juzBreak ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "my-4 flex items-center gap-3 text-xs text-faint",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										juzBreak ? `الجزء ${toArabicDigits(juz)} · ` : "",
										"الصفحة ",
										toArabicDigits(page)
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" })
								]
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								id: `ayah-${surah}-${n}`,
								"data-ayah-row": true,
								"data-ayah": n,
								"data-active": clamped === n,
								"data-playing": playing,
								className: "ayah-block",
								onClick: () => {
									setSel(n);
									setLast(surah, n);
									if (audio.playing) audio.play(surah, n);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "quran-text text-fg",
									children: [verse, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "ayah-mark",
										"aria-label": `تشغيل الآية ${toArabicDigits(n)}`,
										onClick: (event) => {
											event.stopPropagation();
											setSel(n);
											audio.play(surah, n);
										},
										children: toArabicDigits(n)
									})]
								}), isSajda(surah, n) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-gold",
									children: "سجدة"
								}) : null]
							})] }, n);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid grid-cols-2 gap-2",
						children: [surah > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/read/$surah",
							params: { surah: String(surah - 1) },
							search: { a: 1 },
							className: "min-h-12 rounded-xl border border-line px-3 py-3 text-center text-sm",
							children: "السورة السابقة"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), surah < 114 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/read/$surah",
							params: { surah: String(surah + 1) },
							search: { a: 1 },
							className: "min-h-12 rounded-xl border border-line px-3 py-3 text-center text-sm",
							children: "السورة التالية"
						}) : null]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerDock, {
				surah,
				ayah: clamped,
				bookmarked,
				copied,
				onToggleBookmark: () => toggleBookmark(surah, clamped),
				onCopy: () => void copyAyah()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSheet, {
				open: settings,
				onClose: () => setSettings(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JumpSheet, {
				open: jumpOpen,
				onClose: () => setJumpOpen(false),
				surah,
				maxAyah: meta.n
			})
		]
	});
}
function JumpSheet({ open, onClose, surah, maxAyah }) {
	const [page, setPage] = (0, import_react.useState)("");
	const [ayah, setAyah] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setPage("");
		setAyah("");
		setMessage("");
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		title: "انتقال",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				const ayahNo = Number(fromArabicDigits(ayah));
				const pageNo = Number(fromArabicDigits(page));
				if (ayah && (ayahNo < 1 || ayahNo > maxAyah)) {
					setMessage(`أدخل آية بين ١ و${toArabicDigits(maxAyah)}`);
					return;
				}
				if (!ayah && (pageNo < 1 || pageNo > 604)) {
					setMessage("أدخل صفحة بين ١ و٦٠٤");
					return;
				}
				if (ayah) {
					navigate({
						to: "/read/$surah",
						params: { surah: String(surah) },
						search: { a: ayahNo }
					});
					onClose();
					return;
				}
				const loc = locate(pageStart[pageNo - 1] ?? 0);
				navigate({
					to: "/read/$surah",
					params: { surah: String(loc.s) },
					search: { a: loc.a }
				});
				onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-muted",
						children: "آية في هذه السورة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "numeric",
						value: ayah,
						onChange: (event) => setAyah(event.target.value),
						placeholder: `١ – ${toArabicDigits(maxAyah)}`,
						className: "h-12 w-full rounded-xl border border-line bg-bg px-3 text-fg outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-muted",
						children: "أو رقم صفحة المصحف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "numeric",
						value: page,
						onChange: (event) => setPage(event.target.value),
						placeholder: "١ – ٦٠٤",
						className: "h-12 w-full rounded-xl border border-line bg-bg px-3 text-fg outline-none"
					})]
				}),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-gold",
					children: message
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "min-h-12 rounded-xl bg-gold-fill text-sm font-semibold text-on-gold",
					children: "انتقل"
				})
			]
		})
	});
}
function ReaderRoute() {
	const { surah } = Route.useParams();
	const { a } = Route.useSearch();
	const id = Number(surah);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderView, {
		surah: id,
		ayah: a
	});
}
//#endregion
export { ReaderRoute as component };
